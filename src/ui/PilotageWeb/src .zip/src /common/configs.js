import Intl from 'react-intl-universal';
export const PAGE_SIZE = 10;
export const DEFAULT_AVATAR = 'https://gw.alipayobjects.com/zos/rmsportal/BiazfanxmamNRoxxVxka.png';
export const PROJECT_NAME = Intl.get('menu.projectName');
