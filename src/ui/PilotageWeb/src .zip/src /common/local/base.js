export default {
    'en-us': {
  
    },
    'zh-cn': {
      'projectName': '引航平台',
      'pleaseInput': '请输入',
      'reset': '清除',
      'search': '搜索',
      'startTime': '起始时间',
      'endTime': '结束时间',
      'goBack': '返回',
      'confirmDelete': '确定要删除此项内容？',
      'deleteTip': '删除之后将不可恢复',
      'save':'提交',
      'cancel': '取消',
      'networkErr': '网络连接失败'
    },
  };
  