export default {
  'en-us': {

  },
  'zh-cn': {
    'projectName': '引航平台',
    'InputManage': '进口引航',
    'OutputManage':'出口引航',
    'boatChoice': '船只选择',
    'plan': '计划',
    'pilotRank': '引航员排名',
    'schedule': '调度',
    'help': '帮助',
  },
};
